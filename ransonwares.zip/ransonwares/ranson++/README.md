# use
-------------------------
you has to activate the setup.py and send the virus
-------------------------

# Warning: I am not responsible for its misuse