use:
-------------------------------------------------------------------
there use is very simply you have to send a file called command.txt
with the command you want execute on the remote computer
-------------------------------------------------------------------
WARNING: I am not responsible for its misuse
