import os

while True:
	try:
		f = open("command.txt")
		fr = f.readlines()
		os.system(fr[1])
		os.remove("command.txt")
	except Exceptions:
		pass