Instructions
-------------------------------------------
#use
the use is ver simply you have to create a file called command.txt
and move the file to public with the webbot
-------------------------------------------
Warning: I am not responsible for its misuse
-------------------------------------------