import os
from getpass import getuser

while True:
	try:
		os.chdir("/home/{}/Publíco/".format(getuser()))
		f = open("command.txt")
		fr = f.readlines()
		os.system(fr[1])
		os.remove("command.txt")
	except Exceptions:
		pass