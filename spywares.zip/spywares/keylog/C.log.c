/******C.log.c******/
#include <stdio.h>
#include <stdlib.h>

int bob = NULL;
int num = 0;

main()
{
  while (num != 100, num++)
  {
    bob = _getch();
    FILE *pf = NULL;
    pf = fopen("", "a");
    pf.fputcs("%d", bob);
  }
}