Instructions
-----------------------------
#use
the use is very simply you need activate the file sharing
and create a file called log.txt and activate the keylogger
-----------------------------